package com.bookapps.model.controller;

import java.util.Date;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookapps.model.dao.Book;

//REST
@RestController // = @controller + @ResponseBody
public class BookRestController {
	
	@GetMapping("/book")
	public Book getBook() {
		Book book = new Book(12,"java","harshi", 100.00, "abc:", new Date());
		return book;
	}

}
