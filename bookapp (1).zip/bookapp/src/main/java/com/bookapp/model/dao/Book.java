package com.bookapps.model.dao;

import java.util.Date;

public class Book {
	private Integer id;
	private String title;
	private String author;
	private Double price;
	private String pubName;
	private Date pubDate;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getPubName() {
		return pubName;
	}
	public void setPubName(String pubName) {
		this.pubName = pubName;
	}
	public Date getPubDate() {
		return pubDate;
	}
	public void setPubDate(Date pubDate) {
		this.pubDate = pubDate;
	}
	
	
	public Book() {}
	public Book(Integer id, String title, String author, Double price, String pubName, Date pubDate) {
		this.id = id;
		this.title = title;
		this.author = author;
		this.price = price;
		this.pubName = pubName;
		this.pubDate = pubDate;
	}

	

}
