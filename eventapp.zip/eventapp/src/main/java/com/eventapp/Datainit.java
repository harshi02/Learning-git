package com.eventapp;

import java.time.LocalDate;
import java.time.Month;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.eventapp.entities.Event;
import com.eventapp.service.EventService;

@Component
public class Datainit implements CommandLineRunner {

	@Autowired
	private EventService eventService;
	
	@Override
	public void run(String... args) throws Exception {
	
		Event e1 = new Event("bharatnatyam dance",
				"chennai", 500.00, 10, 50, LocalDate.of(2021, Month.FEBRUARY, 21));
		
		Event e2 = new Event("khachapuri dance",
				"banglore", 600.00, 5, 50, 
				LocalDate.of(2021, Month.FEBRUARY, 11));
		
		Event e3 = new Event("bhangra dance", 
				"punjab", 400.00, 10, 100, LocalDate.of(2021, Month.FEBRUARY, 23));
		
		Event e4 = new Event("java basics", 
				"delhi", 100.00, 10, 50, LocalDate.of(2021, Month.FEBRUARY, 19));
		Event e5 = new Event("cooking", 
				"nellore", 100.00, 10, 50, 
				LocalDate.of(2021, Month.FEBRUARY, 24));
		Event e6 = new Event("dance2",
				"chennai", 500.00, 10, 50, LocalDate.of(2021, Month.FEBRUARY, 25));
		Event e7 = new Event("dance4",
				"chennai", 500.00, 10, 50, LocalDate.of(2021, Month.FEBRUARY, 26));
		Event e8 = new Event("dance5", 
				"chennai", 500.00, 10, 50, LocalDate.of(2021, Month.FEBRUARY, 15));
		Event e9 = new Event("dance3", 
				"chennai", 500.00, 10, 50, LocalDate.of(2021, Month.FEBRUARY, 10));
		Event e10 = new Event("dance10",
				"chennai", 500.00, 10, 50, LocalDate.of(2021, Month.FEBRUARY, 17));
		
		
		eventService.addEvent(e1);
		eventService.addEvent(e2);
		eventService.addEvent(e3);
		eventService.addEvent(e4);
		eventService.addEvent(e5);
		eventService.addEvent(e6);
		eventService.addEvent(e7);
		eventService.addEvent(e8);
		eventService.addEvent(e9);
		eventService.addEvent(e10);
		
		
	}

}










