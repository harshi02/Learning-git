package com.eventapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eventapp.entities.Event;
import com.eventapp.service.EventService;

//import com.eventapp.entities.Product;
//import com.eventapp.service.ProductService;


@RestController
@RequestMapping("api")
public class EventRestController {

	private EventService eventService;

	@Autowired
	public EventRestController(EventService eventService) {
		this.eventService = eventService;
	}
	
	
	//---------all product----------
	@GetMapping(path="event", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Event> getAllEvents(){
		List<Event> events=eventService.getAllEvents();
		return events;
	}
//	
//	//--------- productbyId----------
//	@GetMapping(path="product/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<Product> getProductById(@PathVariable(name = "id")int productId){
//		Product product=productService.getProductById(productId);
//		return ResponseEntity.ok(product);
//	}
//	
//	//---------add new product----------
//	@PostMapping(path="product", produces = MediaType.APPLICATION_JSON_VALUE,
//			consumes  = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<Product> addProduct(@Valid  @RequestBody Product product){
//		Product productAdded=productService.addProduct(product);
//		return new ResponseEntity(productAdded, HttpStatus.CREATED);
//	}
//
//	//---------update product----------
//	@PutMapping(path="product/{id}", produces = MediaType.APPLICATION_JSON_VALUE,
//			consumes  = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<Product> updateProduct(@PathVariable(name = "id")int productId, @RequestBody Product product){
//		Product updatedProduct=productService.updateProduct(productId, product);
//		return new ResponseEntity(updatedProduct, HttpStatus.OK);
//	}
//
//	//---------del product---------
//	@DeleteMapping(path="product/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<Void> deleteProduct(@PathVariable(name = "id")int productId){
//		Product productDeleted=productService.deleteProduct(productId);
//		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
//	}
}








