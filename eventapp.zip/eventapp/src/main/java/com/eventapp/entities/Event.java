package com.eventapp.entities;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="event_table")
public class Event {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Id;
//	@Column(name = "product_name", nullable = false, length = 100)
//	@Size(min = 4, max = 50, message = "product size must be between 4 to 50 char")
	private String eventName;
	
	//@Column(name = "product_price", nullable = false, length = 100)
	private String eventLocation;
	
	//@Column(name = "product_discount", nullable = false, length = 100)
	private double eventTicketPrice;
	
	//@Column(name = "product_category", nullable = false, length = 100)
	private double discount;
	
	//@DateTimeFormat(pattern = "dd-MM-yyyy")
//	@Future
//	@Column(name = "product_exp_date", nullable = false)
	private int noOfTicket;

	//@Column(name = "product_qty", nullable = false)
	private LocalDate eventDate;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventLocation() {
		return eventLocation;
	}

	public void setEventLocation(String eventLocation) {
		this.eventLocation = eventLocation;
	}

	public double getEventTicketPrice() {
		return eventTicketPrice;
	}

	public void setEventTicketPrice(double eventTicketPrice) {
		this.eventTicketPrice = eventTicketPrice;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public int getNoOfTicket() {
		return noOfTicket;
	}

	public void setNoOfTicket(int noOfTicket) {
		this.noOfTicket = noOfTicket;
	}

	public LocalDate getEventDate() {
		return eventDate;
	}

	public void setEventDate(LocalDate eventDate) {
		this.eventDate = eventDate;
	}

	public Event(String eventName, String eventLocation, double eventTicketPrice, double discount, int noOfTicket,
			LocalDate eventDate) {
		this.eventName = eventName;
		this.eventLocation = eventLocation;
		this.eventTicketPrice = eventTicketPrice;
		this.discount = discount;
		this.noOfTicket = noOfTicket;
		this.eventDate = eventDate;
	}

	public Event() {}

	@Override
	public String toString() {
		return "Event [Id=" + Id + ", eventName=" + eventName + ", eventLocation=" + eventLocation
				+ ", eventTicketPrice=" + eventTicketPrice + ", discount=" + discount + ", noOfTicket=" + noOfTicket
				+ ", eventDate=" + eventDate + "]";
	}
	
	

}
