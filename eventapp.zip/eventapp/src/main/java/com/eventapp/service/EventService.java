package com.eventapp.service;
import java.time.LocalDate;
import java.util.*;

import com.eventapp.entities.Event;
public interface EventService {
	public List<Event> getAllEvents();
	public Event getEventById(int eventId);
	public Event addEvent(Event event);
	public Event updateEvent(int eventId, Event event);
	public Event deleteEvent(int eventId);
	public List<Event> findByEventName(String eventName);
	public List<Event> findByEventDate(LocalDate date1, LocalDate date2);

}
