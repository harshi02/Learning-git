package com.eventapp.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eventapp.entities.Event;
import com.eventapp.repo.EventRepo;
import com.eventapp.service.exceptions.ResourceNotFoundException;
@Service
@Transactional
public class EventServiceImpl implements EventService {

	private EventRepo eventRepo;
	
	@Autowired
	public EventServiceImpl(EventRepo eventRepo) {
		this.eventRepo = eventRepo;
	}

	@Override
	public Event getEventById(int eventId) {
		return eventRepo.findById(eventId)
				.orElseThrow
				(() -> new ResourceNotFoundException("Event with id:" + eventId + " is not found"));
	}
	
	@Override
	public Event addEvent(Event event) {
		eventRepo.save(event);
		return event;
	}

	@Override
	public Event updateEvent(int eventId, Event event) {
		Event eventToUpdate = getEventById(eventId);
		eventToUpdate.setEventTicketPrice(event.getEventTicketPrice());
		eventToUpdate.setDiscount(event.getDiscount());
		eventToUpdate.setNoOfTicket(event.getNoOfTicket());		
		eventRepo.save(eventToUpdate);
		return eventToUpdate;
	}

	@Override
	public Event deleteEvent(int eventId) {
		Event eventToDelete = getEventById(eventId);
		eventRepo.delete(eventToDelete);
		return eventToDelete;
	}
	
	@Override
	public List<Event> findByEventName(String eventName) {
		return eventRepo.findByEventName(eventName);
	}

	@Override
	public List<Event> findByEventDate(LocalDate date1, LocalDate date2) {
		return eventRepo.findByEventDate(date1, date2);
	}

	@Override
	public List<Event> getAllEvents() {
		return eventRepo.findAll();
	}

		

	
//
//	@Cacheable(value = "Events", key = "#EventId")
//	@Override
//	public Ev getEventById(int EventId) {
//		
//
//	@Override
//	public Event getEventByEventName(String eventName) {
//		return null;
//	}
//
//
//	@CachePut(value = "Events", key = "#result.EventId")
//	@Override
//	public Event addEvent(Event event) {
//		eventRepo.save(event);
//		return event;
//	}
//
//	@CachePut(value = "Events", key = "#result.EventId")
//	@Override
//	public Event updateEvent(int eventId, Event event) {
//		
//	}
//
//	@CacheEvict(value = "Events", key="#EventId")
//	@Override
//	public Event deleteEvent(int eventId) {
//		
//	}
//
//	//how to call this method periodically?
//	// spring boot scheduled process: cron job linux system
//	
////	@CacheEvict(value = "Events", allEntries = true)
////	@Override
////	public void evictCache() {
////	}

}
